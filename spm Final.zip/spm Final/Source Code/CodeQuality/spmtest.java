public Class Sachin{
	public void cal(String args) {
		int s;
		if (s=2) {
			System.out.println(sachin);
			
		}

	}
}