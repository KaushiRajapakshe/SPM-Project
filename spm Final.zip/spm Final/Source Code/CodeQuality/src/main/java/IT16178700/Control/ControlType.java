package IT16178700.Control;

public class ControlType {
    // static variable define for check type of control

    public static String ifV ="if";
    public static String systemV = "System";
    public static String elseIfV = "else if";
    public static String forV = "for";
    public static String whileV = "while";
    public static String doV = "do";
    public static String andVM = "&&";
    public static String andVS = "&";
    public static String orVM = "||";
    public static String orVS = "|";
    public static String catchV = "catch";
    public static String switchV = "switch";
    public static String caseV = "case";
    public static String intV = "int";
    public static String floatV = "float";
    public static String doubleV = "doubleV";
    public static String stringV = "string";
    public static String StringV = "String";
    public static String FloatV = "Float";
    public static String IntegerV = "Integer";
    public static String booleanV = "boolean";
    public static String DoubleV = "Double";
    public static String ArrayListV = "ArrayList";
    public static String ArrayV = "Array";
    public static String publicV = "public";
    public static String privateV = "private";
    public static String returnV = "return";
    public static String longV = "long";
    public static String LongV = "Long";
    public static String classV = "class";
    public static String protectedV = "protected";
    public static String bracketO = "{";
    public static String bracketC = "}";
    public static String elseV = "else";
    public static String  bracket = "==";
    public static String thisV = "this";
    public static String semiColumn = ";";
    public static String checkAndS = "\"&\"";
    public static String checkAndM = "\"&&\"";

}
